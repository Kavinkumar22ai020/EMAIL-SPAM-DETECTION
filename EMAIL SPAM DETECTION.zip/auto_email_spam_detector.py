from imapclient import IMAPClient
import pyzmail
import pickle
import json
import os
from datetime import datetime

EMAIL = "klutchkavin@gmail.com"
PASSWORD = "ybha wxeq qvry khwj"
HOST = "imap.gmail.com"

HISTORY_FILE = "auto_mail_history.json"

if not os.path.exists(HISTORY_FILE):
    with open(HISTORY_FILE, "w") as f:
        json.dump([], f)

model = pickle.load(open("Naive_model.pkl", "rb"))

IGNORE_KEYWORDS = [
    "google",
    "security alert",
    "2-step verification",
    "app password",
    "account"
]

with IMAPClient(HOST) as server:
    server.login(EMAIL, PASSWORD)
    server.select_folder("INBOX")

    messages = server.search(["UNSEEN"])

    for uid in messages:
        raw = server.fetch(uid, ["BODY[]"])
        msg = pyzmail.PyzMessage.factory(raw[uid][b"BODY[]"])

        if msg.text_part:
            text = msg.text_part.get_payload().decode(
                msg.text_part.charset, errors="ignore"
            )

            lower_text = text.lower()

            if any(k in lower_text for k in IGNORE_KEYWORDS):
                label = "SYSTEM"
            else:
                pred = model.predict([text])[0]
                label = "SPAM" if pred == 1 else "NOT_SPAM"

            record = {
                "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "content": text[:200],
                "label": label
            }

            with open(HISTORY_FILE, "r+") as f:
                data = json.load(f)
                data.insert(0, record)
                f.seek(0)
                json.dump(data, f, indent=4)

            server.add_flags(uid, ["\\Seen"])
