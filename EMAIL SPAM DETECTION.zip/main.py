import warnings
warnings.filterwarnings("ignore")

import threading, time, json, os
import imaplib, email
from datetime import datetime
from flask import Flask, render_template, request, jsonify
import joblib

# ================= MODEL =================
model = joblib.load("Naive_bayes_model.pkl")

# ================= FILES =================
AUTO_FILE = "auto_history.json"
MANUAL_FILE = "manual_history.json"

for f in [AUTO_FILE, MANUAL_FILE]:
    if not os.path.exists(f):
        with open(f, "w") as fp:
            json.dump([], fp)

# ================= HELPERS =================
def save_history(file, content, label):
    with open(file, "r+") as f:
        data = json.load(f)
        data.insert(0, {
            "content": content[:200],
            "label": label,
            "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        })
        f.seek(0)
        json.dump(data, f, indent=2)

def load_history(file):
    with open(file) as f:
        return json.load(f)

# ================= AUTO DETECTOR =================
def auto_detector():
    EMAIL = "klutchkavin@gmail.com"
    APP_PASSWORD = "ybha wxeq qvry khwj"

    while True:
        try:
            mail = imaplib.IMAP4_SSL("imap.gmail.com")
            mail.login(EMAIL, APP_PASSWORD)
            mail.select("inbox")

            _, messages = mail.search(None, "UNSEEN")
            for num in messages[0].split():
                _, data = mail.fetch(num, "(RFC822)")
                msg = email.message_from_bytes(data[0][1])

                body = ""
                if msg.is_multipart():
                    for part in msg.walk():
                        if part.get_content_type() == "text/plain":
                            body += part.get_payload(decode=True).decode(errors="ignore")
                else:
                    body = msg.get_payload(decode=True).decode(errors="ignore")

                if "google" in body.lower() or "security alert" in body.lower():
                    label = "SYSTEM"
                else:
                    pred = model.predict([body])[0]
                    label = "SPAM" if pred == 1 else "NOT_SPAM"

                save_history(AUTO_FILE, body, label)

            mail.logout()
        except Exception as e:
            print("Auto error:", e)

        time.sleep(60)

# ================= FLASK =================
app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def index():
    prediction = None
    email_text = ""

    if request.method == "POST":
        email_text = request.form["email"]
        pred = model.predict([email_text])[0]
        prediction = "SPAM" if pred == 1 else "NOT_SPAM"
        save_history(MANUAL_FILE, email_text, prediction)

    return render_template(
        "index.html",
        prediction=prediction,
        email_text=email_text
    )

@app.route("/api/history")
def api_history():
    return jsonify({
        "auto": load_history(AUTO_FILE),
        "manual": load_history(MANUAL_FILE)
    })

# ================= START =================
if __name__ == "__main__":
    threading.Thread(target=auto_detector, daemon=True).start()
    app.run(debug=True)
